# Luccaix CRM – passo a passo (≈20 min)

## 1. Supabase (banco + login)
1. Crie conta em supabase.com e clique em **New project** (plano gratuito).
2. Menu **SQL Editor** > New query > cole o conteúdo de `supabase/schema.sql` > **Run**.
3. Menu **Authentication > Sign In / Providers > Email**: desligue **Confirm email** (assim você entra logo após criar a conta).
4. Menu **Project Settings > API**: copie **Project URL** e **anon public key** e cole em `config.js`.

## 2. Chave do Google (busca de empresas)
1. Em console.cloud.google.com crie um projeto e ative o faturamento (o Google dá crédito mensal gratuito).
2. **APIs e serviços > Biblioteca**: ative **Places API (New)**.
3. **Credenciais > Criar credenciais > Chave de API**. Em restrições da chave, limite à Places API (New).

## 3. Função de servidor (guarda a chave com segurança)
1. No Supabase: **Edge Functions > Deploy a new function > Via Editor**.
2. Nome: `search-leads`. Cole o conteúdo de `supabase/functions/search-leads/index.ts` e faça o Deploy.
3. **Edge Functions > Secrets**: adicione `GOOGLE_PLACES_API_KEY` com a chave do passo 2.

## 4. Publicar na Vercel
1. Em vercel.com: **Add New > Project** e envie esta pasta (via GitHub, ou arrastando a pasta pelo Vercel CLI/dashboard).
2. Framework: **Other**, sem build command. Clique **Deploy**.
3. Abra o link, crie sua conta e use **Encontrar Leads**.

Para testar localmente antes: `npx serve .` dentro da pasta.
