// Cole aqui os dados do seu projeto Supabase (Project Settings > API)
export const SUPABASE_URL = "COLE_AQUI_A_PROJECT_URL";
export const SUPABASE_ANON_KEY = "COLE_AQUI_A_ANON_PUBLIC_KEY";
