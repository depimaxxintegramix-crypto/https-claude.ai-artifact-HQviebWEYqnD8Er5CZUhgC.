import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const { query } = await req.json();
    if (!query || String(query).trim().length < 3) return json({ error: "Digite uma busca, ex: pizzarias em Guarulhos" }, 400);

    const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } },
    });
    const { data: u } = await sb.auth.getUser();
    if (!u?.user) return json({ error: "Faça login novamente." }, 401);

    const key = Deno.env.get("GOOGLE_PLACES_API_KEY");
    if (!key) return json({ error: "Chave GOOGLE_PLACES_API_KEY não configurada no Supabase." }, 500);

    const r = await fetch("https://places.googleapis.com/v1/places:searchText", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": key,
        "X-Goog-FieldMask": "places.id,places.displayName,places.formattedAddress,places.nationalPhoneNumber,places.websiteUri,places.googleMapsUri",
      },
      body: JSON.stringify({ textQuery: query, languageCode: "pt-BR", regionCode: "BR", pageSize: 20 }),
    });
    const g = await r.json();
    if (!r.ok) return json({ error: g?.error?.message ?? "Erro na API do Google" }, 502);

    const places = g.places ?? [];
    const rows = places.map((p: any) => ({
      user_id: u.user.id,
      place_id: p.id,
      name: p.displayName?.text ?? "Sem nome",
      segment: String(query).split(/ em | in /i)[0],
      city: String(query).split(/ em | in /i)[1] ?? null,
      address: p.formattedAddress ?? null,
      phone: p.nationalPhoneNumber ?? null,
      website: p.websiteUri ?? null,
      maps_url: p.googleMapsUri ?? null,
    }));

    let added = 0;
    if (rows.length) {
      const { data, error } = await sb.from("leads")
        .upsert(rows, { onConflict: "user_id,place_id", ignoreDuplicates: true }).select("id");
      if (error) return json({ error: error.message }, 500);
      added = data?.length ?? 0;
    }
    return json({ found: rows.length, added, duplicates: rows.length - added });
  } catch (e) {
    return json({ error: String(e) }, 500);
  }
});
