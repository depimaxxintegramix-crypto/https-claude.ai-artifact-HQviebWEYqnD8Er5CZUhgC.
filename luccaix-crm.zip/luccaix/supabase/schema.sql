create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name text not null,
  segment text, city text, address text, phone text, website text, maps_url text,
  place_id text,
  stage text not null default 'novo',
  value numeric not null default 0,
  monthly numeric not null default 0,
  next_contact date,
  notes text,
  created_at timestamptz not null default now(),
  unique (user_id, place_id)
);
alter table public.leads enable row level security;
create policy "dono ve e edita seus leads" on public.leads
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
